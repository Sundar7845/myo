    <!doctype html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Myo</title>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('dist/img/logo-myo.png')); ?>">
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
        <link
            href="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>"rel="stylesheet">

        <link href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/summernote/summernote-bs4.css')); ?>" rel="stylesheet">
        <link rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
        <link href="<?php echo e(asset('dist/css/custom.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('dist/css/student-css.css')); ?>" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Jost:wght@200;300;400;500;600;700&display=swap"
            rel="stylesheet">
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
        <link href="<?php echo e(asset('plugins/jqvmap/jqvmap.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"
        integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/jquery-ui/jquery-ui.min.js')); ?>"></script>
      
        <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/chart.js/Chart.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/sparklines/sparkline.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/jquery-knob/jquery.knob.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/moment/moment.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/summernote/summernote-bs4.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/pages/dashboard.js')); ?>"></script>
        <script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>
        <script>
            $.widget.bridge('uibutton', $.ui.button)
        </script>
        <script language="JavaScript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
        </script>
        <script src="<?php echo e(asset('plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>
        <script src="<?php echo e(asset('plugins/select2/js/select2.full.min.js')); ?>"></script>
        
    </head>

    <body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">

            <!-- Navbar -->
            <nav class="main-header navbar navbar-expand navbar-white navbar-light custom-dashboard-section">
                <div class="dashboard-header-section">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                                    class="fas fa-bars"></i></a>
                        </li>
                    </ul>
                    <div class="content-section">
                        <div class="welcome--text-section">
                            <div class="left-content--item">
                                <h5>Welcome <span>
                                        <?php if(isset(Auth::user()->name)): ?>
                                            <?php echo e(Auth::user()->name); ?>

                                        <?php endif; ?>
                                    </span></h5>
                            </div>
                            <div class="middle-content--item">
                                <p>You need to finish your <a href="/student-edit-profile">profile</a>, set up insurance and finish your
                                    payment
                                    settings before you can create your first class. please see our <a href="/student-faq">FAQ</a> for
                                    more information.</p>
                            </div>
                            <div class="right-profile--item">
                                <div class="profile-flex-section">
                                    <div class="left-profile-detail dropdown">
                                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#"
                                            role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false" v-pre>
                                            <?php if(isset(Auth::user()->name)): ?>
                                                <?php echo e(Auth::user()->name); ?>

                                            <?php endif; ?>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                onclick="event.preventDefault();
                                     document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Logout')); ?>

                                            </a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                        <p><?php echo e(auth::user()->userRole->role); ?>

                                        </p>
                                    </div>
                                    <div class="right-profile-img">
                                        <span><img alt="avatar" src="<?php echo e(route('studentProfileImage', auth()->user()->id)); ?>"
                                                class="brround"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            <aside class="main-sidebar sidebar-dark-primary">
                <a href="/dashboard" class="brand-link">
                    <img src="<?php echo e(asset('dist/img/logo-2.svg')); ?>" alt="AdminLTE Logo" class="brand-image" />
                </a>

                <!-- Sidebar -->
                <div class="sidebar myo-sidebar-section">
                    <!-- Sidebar Menu -->
                    <nav>
                        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                            data-accordion="false">
                            <!-- Add icons to the links using the .nav-icon class
            with font-awesome or any other icon font library -->
                            <li class="nav-item has-treeview ">
                                <a href="<?php echo e(route('dashboard.index')); ?>"
                                    class="nav-link <?php if(in_array(Route::currentRouteName(), ['dashboard.index'])): ?> active <?php endif; ?><?php echo e(request()->route()->uri); ?>">
                                    <span class="left-icon-item">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25"
                                            viewBox="0 0 25 25" fill="none" stroke="#474B4F" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path
                                                d="M12.5 22.2715C18.0228 22.2715 22.5 17.7943 22.5 12.2715C22.5 6.74864 18.0228 2.27148 12.5 2.27148C6.97715 2.27148 2.5 6.74864 2.5 12.2715C2.5 17.7943 6.97715 22.2715 12.5 22.2715Z" />
                                            <path
                                                d="M16.74 8.03149L14.62 14.3915L8.26001 16.5115L10.38 10.1515L16.74 8.03149Z" />
                                        </svg>
                                    </span>
                                    <p>
                                        Explore
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview ">
                                <a href="<?php echo e(route('studentclass.index')); ?>"
                                    class="nav-link <?php if(in_array(Route::currentRouteName(), ['studentclass.index'])): ?> active <?php endif; ?><?php echo e(request()->route()->uri); ?>">
                                    <span class="left-icon-item">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                            viewBox="0 0 22 22" fill="none"stroke="#474B4F" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path
                                                d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                        </svg>
                                    </span>
                                    <p>
                                        Manage Classes
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview ">
                                <a href="<?php echo e(route('studentinstructor.index')); ?>"
                                    class="nav-link <?php if(in_array(Route::currentRouteName(), ['studentinstructor.index', 'studentinstructor.view'])): ?> active <?php endif; ?><?php echo e(request()->route()->uri); ?>">
                                    <span class="left-icon-item">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none" stroke="#474B4F" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path
                                                d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" />
                                            <path
                                                d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" />
                                        </svg>
                                    </span>
                                    <p>
                                        My Instructor
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview ">
                                <a href="<?php echo e(route('studentinstructor.viewprofile')); ?>"
                                    class="nav-link <?php if(in_array(Route::currentRouteName(), ['studentinstructor.viewprofile', 'studentinstructor.editprofile'])): ?> active <?php endif; ?><?php echo e(request()->route()->uri); ?>">
                                    <span class="left-icon-item">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                            viewBox="0 0 24 24" fill="none"stroke="#474B4F" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path
                                                d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" />
                                            <path
                                                d="M19.4 15C19.2669 15.3016 19.2272 15.6362 19.286 15.9606C19.3448 16.285 19.4995 16.5843 19.73 16.82L19.79 16.88C19.976 17.0657 20.1235 17.2863 20.2241 17.5291C20.3248 17.7719 20.3766 18.0322 20.3766 18.295C20.3766 18.5578 20.3248 18.8181 20.2241 19.0609C20.1235 19.3037 19.976 19.5243 19.79 19.71C19.6043 19.896 19.3837 20.0435 19.1409 20.1441C18.8981 20.2448 18.6378 20.2966 18.375 20.2966C18.1122 20.2966 17.8519 20.2448 17.6091 20.1441C17.3663 20.0435 17.1457 19.896 16.96 19.71L16.9 19.65C16.6643 19.4195 16.365 19.2648 16.0406 19.206C15.7162 19.1472 15.3816 19.1869 15.08 19.32C14.7842 19.4468 14.532 19.6572 14.3543 19.9255C14.1766 20.1938 14.0813 20.5082 14.08 20.83V21C14.08 21.5304 13.8693 22.0391 13.4942 22.4142C13.1191 22.7893 12.6104 23 12.08 23C11.5496 23 11.0409 22.7893 10.6658 22.4142C10.2907 22.0391 10.08 21.5304 10.08 21V20.91C10.0723 20.579 9.96512 20.258 9.77251 19.9887C9.5799 19.7194 9.31074 19.5143 9 19.4C8.69838 19.2669 8.36381 19.2272 8.03941 19.286C7.71502 19.3448 7.41568 19.4995 7.18 19.73L7.12 19.79C6.93425 19.976 6.71368 20.1235 6.47088 20.2241C6.22808 20.3248 5.96783 20.3766 5.705 20.3766C5.44217 20.3766 5.18192 20.3248 4.93912 20.2241C4.69632 20.1235 4.47575 19.976 4.29 19.79C4.10405 19.6043 3.95653 19.3837 3.85588 19.1409C3.75523 18.8981 3.70343 18.6378 3.70343 18.375C3.70343 18.1122 3.75523 17.8519 3.85588 17.6091C3.95653 17.3663 4.10405 17.1457 4.29 16.96L4.35 16.9C4.58054 16.6643 4.73519 16.365 4.794 16.0406C4.85282 15.7162 4.81312 15.3816 4.68 15.08C4.55324 14.7842 4.34276 14.532 4.07447 14.3543C3.80618 14.1766 3.49179 14.0813 3.17 14.08H3C2.46957 14.08 1.96086 13.8693 1.58579 13.4942C1.21071 13.1191 1 12.6104 1 12.08C1 11.5496 1.21071 11.0409 1.58579 10.6658C1.96086 10.2907 2.46957 10.08 3 10.08H3.09C3.42099 10.0723 3.742 9.96512 4.0113 9.77251C4.28059 9.5799 4.48572 9.31074 4.6 9C4.73312 8.69838 4.77282 8.36381 4.714 8.03941C4.65519 7.71502 4.50054 7.41568 4.27 7.18L4.21 7.12C4.02405 6.93425 3.87653 6.71368 3.77588 6.47088C3.67523 6.22808 3.62343 5.96783 3.62343 5.705C3.62343 5.44217 3.67523 5.18192 3.77588 4.93912C3.87653 4.69632 4.02405 4.47575 4.21 4.29C4.39575 4.10405 4.61632 3.95653 4.85912 3.85588C5.10192 3.75523 5.36217 3.70343 5.625 3.70343C5.88783 3.70343 6.14808 3.75523 6.39088 3.85588C6.63368 3.95653 6.85425 4.10405 7.04 4.29L7.1 4.35C7.33568 4.58054 7.63502 4.73519 7.95941 4.794C8.28381 4.85282 8.61838 4.81312 8.92 4.68H9C9.29577 4.55324 9.54802 4.34276 9.72569 4.07447C9.90337 3.80618 9.99872 3.49179 10 3.17V3C10 2.46957 10.2107 1.96086 10.5858 1.58579C10.9609 1.21071 11.4696 1 12 1C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V3.09C14.0013 3.41179 14.0966 3.72618 14.2743 3.99447C14.452 4.26276 14.7042 4.47324 15 4.6C15.3016 4.73312 15.6362 4.77282 15.9606 4.714C16.285 4.65519 16.5843 4.50054 16.82 4.27L16.88 4.21C17.0657 4.02405 17.2863 3.87653 17.5291 3.77588C17.7719 3.67523 18.0322 3.62343 18.295 3.62343C18.5578 3.62343 18.8181 3.67523 19.0609 3.77588C19.3037 3.87653 19.5243 4.02405 19.71 4.21C19.896 4.39575 20.0435 4.61632 20.1441 4.85912C20.2448 5.10192 20.2966 5.36217 20.2966 5.625C20.2966 5.88783 20.2448 6.14808 20.1441 6.39088C20.0435 6.63368 19.896 6.85425 19.71 7.04L19.65 7.1C19.4195 7.33568 19.2648 7.63502 19.206 7.95941C19.1472 8.28381 19.1869 8.61838 19.32 8.92V9C19.4468 9.29577 19.6572 9.54802 19.9255 9.72569C20.1938 9.90337 20.5082 9.99872 20.83 10H21C21.5304 10 22.0391 10.2107 22.4142 10.5858C22.7893 10.9609 23 11.4696 23 12C23 12.5304 22.7893 13.0391 22.4142 13.4142C22.0391 13.7893 21.5304 14 21 14H20.91C20.5882 14.0013 20.2738 14.0966 20.0055 14.2743C19.7372 14.452 19.5268 14.7042 19.4 15V15Z" />
                                        </svg>
                                    </span>
                                    <p>
                                        Profile & Settings
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item has-treeview ">
                                <a href="<?php echo e(route('student.faq')); ?>"
                                    class="nav-link <?php if(in_array(Route::currentRouteName(), ['student.faq'])): ?> active <?php endif; ?><?php echo e(request()->route()->uri); ?>">
                                    <span class="left-icon-item">
                                    <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                                    width="640px" height="480px" viewBox="0 0 640 480" enable-background="new 0 0 640 480" xml:space="preserve">
                                <g>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M141.229,264.72c1.469-7.314,2.473-14.76,4.484-21.922
                                        c12.397-44.141,52.096-76.855,97.655-80.992c18.907-1.717,37.07,0.913,54.577,8.211c0.57,0.238,1.174,0.398,1.632,0.552
                                        c1.948-7.625,3.443-15.314,5.874-22.695c16.206-49.226,65.285-81.089,116.854-76.084c53.01,5.145,94.145,44.343,101.908,97.104
                                        c0.287,1.951,0.645,3.892,0.968,5.838c0,5.749,0,11.498,0,17.248c-1.072,5.996-1.791,12.081-3.278,17.971
                                        c-5.991,23.731-18.486,43.494-37.177,59.272c-2.108,1.78-2.428,3.241-1.517,5.698c3.299,8.905,7.993,16.909,14.641,23.721
                                        c2.748,2.815,4.447,6.026,4.002,10.074c-0.544,4.952-4.447,9.705-9.414,9.723c-11.956,0.043-24.031,0.271-35.841-1.26
                                        c-13.098-1.698-23.486-9.25-31.979-19.337c-0.89-1.058-2.597-2.206-3.812-2.093c-18.182,1.689-35.557-1.429-52.348-8.342
                                        c-0.573-0.235-1.174-0.403-1.63-0.558c-1.944,7.611-3.433,15.307-5.874,22.687c-15.574,47.073-61.078,78.594-110.524,76.422
                                        c-4.939-0.217-7.946,0.792-11.305,4.563c-10.762,12.08-24.643,17.939-40.831,18.162c-7.245,0.1-14.493-0.005-21.74,0.025
                                        c-5.124,0.021-9.011-2.104-11.095-6.804c-2.104-4.747-0.918-9.063,2.623-12.724c6.881-7.112,11.918-15.325,15.221-24.659
                                        c0.782-2.21,0.487-3.507-1.364-5.073c-20.667-17.482-33.728-39.496-38.906-66.106c-0.733-3.766-1.209-7.581-1.804-11.374
                                        C141.229,276.219,141.229,270.47,141.229,264.72z M199.312,386.218c12.075-0.754,21.496-6.354,27.933-16.965
                                        c3.785-6.241,7.361-8.07,14.275-6.798c11.119,2.046,22.127,1.414,33.083-1.04c39.206-8.783,68.936-44.649,69.708-84.261
                                        c0.033-1.697-0.766-4.024-2.008-5.041c-23.137-18.923-37.26-42.965-41.627-72.598c-0.363-2.473-1.363-3.916-3.588-5.07
                                        c-22.873-11.864-46.636-14.061-71.099-6.119c-42.636,13.843-68.382,56.308-60.811,100.404
                                        c4.173,24.309,17.032,43.409,36.833,57.871c5.197,3.796,7.259,8.464,5.365,14.6C204.816,369.498,202.057,377.734,199.312,386.218z
                                        M467.308,296.206c-2.585-7.432-5.454-14.602-7.561-21.988c-2.922-10.249-1.747-12.573,6.678-19.1
                                        c21.696-16.808,34.274-38.84,36.059-66.3c3.673-56.521-47.592-102.84-103.753-94.147c-48.117,7.449-81.259,50.588-76.146,99.117
                                        c5.196,49.318,51.037,85.711,99.974,78.936c8.17-1.132,13.374,0.677,17.691,7.959C446.241,290.787,455.832,295.646,467.308,296.206
                                        z"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M220.703,273.765c-0.03,6.077-5.119,11.164-11.191,11.188
                                        c-6.215,0.026-11.406-5.256-11.277-11.474c0.126-6.072,5.304-11.078,11.376-10.999
                                        C215.689,262.561,220.732,267.691,220.703,273.765z"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M265.697,273.689c0.012,6.077-5.039,11.196-11.115,11.264
                                        c-6.214,0.07-11.44-5.177-11.354-11.397c0.085-6.07,5.229-11.112,11.301-11.075C260.608,262.519,265.686,267.613,265.697,273.689z"
                                        />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M310.691,273.668c0.025,6.076-5.017,11.206-11.093,11.285
                                        c-6.211,0.082-11.45-5.156-11.376-11.376c0.074-6.072,5.205-11.121,11.278-11.097C305.579,262.506,310.667,267.592,310.691,273.668
                                        z"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M412.141,116.25c13.994,0.064,26.581,8.902,31.387,22.035
                                        c4.958,13.549,1.166,28.543-10.084,37.578c-6.474,5.197-10.182,11.312-10.353,19.744c-0.125,6.133-5.426,10.737-11.387,10.606
                                        c-5.975-0.131-10.937-4.923-10.959-11.082c-0.054-14.535,5.769-26.34,17.059-35.466c4.706-3.804,6.313-7.968,4.896-12.692
                                        c-1.573-5.244-6.307-8.604-11.561-8.208c-5.212,0.394-9.569,4.483-10.352,9.76c-0.128,0.86-0.049,1.751-0.157,2.616
                                        c-0.75,5.923-5.775,10.285-11.577,10.074c-5.968-0.217-10.686-5.105-10.841-11.233C377.753,131.831,393.511,116.164,412.141,116.25
                                        z"/>
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M412.079,217.486c6.079,0.077,11.125,5.205,11.099,11.278
                                        c-0.027,6.223-5.353,11.38-11.559,11.194c-6.067-0.182-11.033-5.4-10.91-11.468C400.832,222.42,406.009,217.41,412.079,217.486z"/>
                                </g>
                                </svg>
                                    </span>
                                    <p>
                                        FAQ
                                    </p>
                                </a>
                            </li>
                        </ul>
                        <div class="copy-right-content">
                            <p>© 2022 MYO</p>
                        </div>
                    </nav>
                </div>
            </aside>
            <main>
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
        </div>
    </body>

    </html>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.select2').select2();
            $("#carousel").owlCarousel({
                autoplay: true,
                rewind: true,
                margin: 25,
                dots: false,
                responsiveClass: true,
                autoHeight: true,
                autoplayTimeout: 7000,
                smartSpeed: 800,
                nav: false,
                responsive: {
                    0: {
                        items: 1
                    },

                    600: {
                        items: 2
                    },

                    1024: {
                        items: 3
                    },

                    1366: {
                        items: 2.8
                    },

                    1440: {
                        items: 3.6
                    }
                }
            });
        });
    </script>
<?php /**PATH D:\xampp\htdocs\projects\myoo-latest\resources\views/student_layouts/app.blade.php ENDPATH**/ ?>