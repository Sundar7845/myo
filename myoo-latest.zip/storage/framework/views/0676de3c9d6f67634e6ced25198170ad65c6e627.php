<script type="text/javascript">
    $(document).ready(function() {

        $("#mobilenumber").keypress(function(e) {
            $('#mobilenumbererror').hide();
            var value = $(this).val();
            var newvalue = value.replace(/-/g, "");
            $("#phonedefaulterror").hide();
            $(this).val($(this).val().replace(/(\d{3})\?(\d{3})\?(\d{4})/, '$1$2$3'))
            if (!(e.which >= 48 && e.which <= 57) || newvalue.length >= 16) {
                $("#phonedigiterror").show().fadeOut(4000);
                return false;
            }
        });

        $("#mobilenumber").blur(function(e) {
            $('#mobilenumbererror').hide();
            var value = $(this).val();
            var newvalue = value.replace(/-/g, "");
            if (newvalue.length > 0 && newvalue.length < 16) {
                $("#phonedefaulterror").show();
            }
        });

        $('#mobilenumber').click(function() {
            $("#phonedefaulterror").hide();
            var value = $(this).val();
            if (value.length == 0) {
                $('#mobilenumbererror').show();
            }
        });

        $("#zipcode").keypress(function(e) {
            var value = $(this).val();
            var newvalue = value.replace(/-/g, "");
            $(this).val($(this).val().replace(/(\d{3})\?(\d{3})\?(\d{4})/, '$1$2$3'))
            if (!(e.which >= 48 && e.which <= 57) || newvalue.length >= 6) {
                $("#zipcodeerror").show().fadeOut(4000);
                return false;
            }
        });

    });
</script>
<?php /**PATH F:\myoo-karthi\resources\views/scripts/register-script.blade.php ENDPATH**/ ?>