<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Summary
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">
                        <div class="add-form-view-section summery-card-section">
                            <div class="summary-inner-item">
                                <div class="row mb-3">
                                    <div class="col-12 col-md-6">
                                        <div class="left-summary-text text-right">
                                            <h4>Title :</h4>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="right-summary-text text-left">
                                            <h4><?php echo e($summary->title); ?></h4>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-12 col-md-6">
                                        <div class="left-summary-text text-right">
                                            <h4>Class :</h4>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <div class="right-summary-text text-left">
                                            <h4><?php echo e($summary->class->type); ?></h4>
                                        </div>
                                    </div>
                                </div>
                                <?php if($yogatype == 1): ?>
                                    <div class="row mb-3">
                                        <div class="col-12 col-md-6">
                                            <div class="left-summary-text text-right">
                                                <h4>Yoga Types :</h4>
                                            </div>
                                        </div>
                                <?php endif; ?>
                                <div class="col-12 col-md-6">
                                    <div class="right-summary-text text-left">
                                        <h4><?php
                                            $i = 0;
                                        ?>
                                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($i != 0): ?>
                                                    , <?php echo e($users->type); ?>

                                                <?php else: ?>
                                                    <?php echo e($users->type); ?>

                                                <?php endif; ?>
                                                <?php
                                                    $i++;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </h4>
                                    </div>
                                </div>
                            </div>
                            <div class="row  mb-3">
                                <div class="col-12 col-md-6">
                                    <div class="left-summary-text text-right">
                                        <h4>Start Date :</h4>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="right-summary-text text-left">
                                        <h4><?php echo e(date('d-m-y h:i A', strtotime($summary->start_date))); ?></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="row  mb-3">
                                <div class="col-12 col-md-6">
                                    <div class="left-summary-text text-right">
                                        <h4>End Date :</h4>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="right-summary-text text-left">
                                        <h4><?php echo e(date('d-m-y h:i A', strtotime($summary->end_date))); ?></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="row  mb-3">
                                <div class="col-12 col-md-6">
                                    <div class="left-summary-text text-right">
                                        <h4>Venue :</h4>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="right-summary-text text-left">
                                        <h4><?php echo e($summary->venue->title); ?></h4>
                                    </div>
                                </div>
                            </div>
                            <div class="submit-btn-section">
                                <a href="<?php echo e(route('inviteshare', ['id' => $summary->id])); ?>">
                                    <div class="submit-btn-section text-center">
                                        <button class="btn submit-btn">Publish</button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </div>
    </section>
    </div>
    <footer class="main-footer">
        </div> -->
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/instructor/offering/summary.blade.php ENDPATH**/ ?>