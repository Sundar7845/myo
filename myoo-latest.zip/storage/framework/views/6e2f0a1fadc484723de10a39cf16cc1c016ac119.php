<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            My Offerings
                        </h4>
                    </div>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
                            <?php echo e(Session::get('message')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>
                    <div class="card-body dashboard-card-body">

                        <div class="table-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>Offerings</h4>
                                    <div class="d-flex ml-auto view-offer-secrion">
                                        <a class="btn add-newclass-btn" href="/add-class"><span>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none">
                                                    <path
                                                        d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z"
                                                        stroke="white" stroke-width="2" stroke-linecap="round"
                                                        stroke-linejoin="round" />
                                                    <path d="M12 8V16" stroke="white" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round" />
                                                    <path d="M8 12H16" stroke="white" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </span> Add New Class </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="offering-table-item">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Title</th>
                                                
                                                <th>Revenue</th>
                                                <th>Location</th>
                                                <th>Date & Time</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $serialNo = 1;
                                            ?>
                                            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($serialNo); ?></td>
                                                    <td><?php echo e($offer->title); ?></td>
                                                    <td>$ 50</td>
                                                    <td><?php echo e($offer->venue->title); ?></td>
                                                    <?php
                                                        $start_date = date('d-m-Y h:i A', strtotime($offer->start_date));
                                                        $end_date = date('d-m-Y h:i A', strtotime($offer->end_date));

                                                        $dates = implode(' - ', [$start_date, $end_date]);
                                                    ?>
                                                    <td><?php echo e($dates); ?>

                                                    </td>
                                                    <td>Active</td>
                                                    <td>
                                                        <a href="<?php echo e(route('offering.edit', $offer->id)); ?>"
                                                            class="btn btn-primary btn-sm"data-toggle="tooltip" title='Edit'><i class='fas fa-edit'></i></a>
                                                        <form action="<?php echo e(route('offering.destroy', $offer->id)); ?>"
                                                            method="GET" style="display: inline-block">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <input name="_method" type="hidden" value="DELETE">
                                                            <button
                                                                class="btn btn-danger btn-sm btn-danger btn-flat show_confirm"
                                                                type="submit" data-toggle="tooltip" title='Delete'><i
                                                                    class="fa fa-trash"></i></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php
                                                    $serialNo++;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    </div>
    <footer class="main-footer">
        </div> -->
    </footer>
    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
    <script src="<?php echo e(asset('js/delete-confirmation.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-latest\resources\views/instructor/offering/index.blade.php ENDPATH**/ ?>