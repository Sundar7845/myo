<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Invite Share
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">

                        <div class="table-view-section">
                            <div class="card table-card-view">
                                <div class="card-body">
                                    <div class="invite-section">
                                        <div class="card-invite-section">
                                            <div class="card-head">
                                                <div class="card-heading">
                                                    <h3>Invite, Share, Spread The Love</h3>
                                                </div>
                                                <div class="body-content">
                                                    <p>To get the most from your listing, share across all your
                                                        social media platforms. Don't worry,
                                                        we made i easy with template and links that go directly to
                                                        the booking page.</p>
                                                </div>
                                                <div class="social-link">
                                                    <div class="row">
                                                        <?php echo $__env->make('instructor.offering.socialmedia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </div>
                                                    <div class="flyer">
                                                        <div class="row">
                                                            <div>
                                                                <a href="#" class="flyer-btn">Create a Flyer!
                                                                    (QR Code
                                                                    Included)</a>
                                                            </div>
                                                            <div class="qr-input-field">
                                                                <span>OR Copy/Paste to post to any platform</span>
                                                                <input type="text" class="text-area">
                                                                <div class="connect-btn">
                                                                    <a href="#">Connect to Gmail Contacts</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-invite-body mt-3">

                                                    <div class="tab-content" id="nav-tabContent">
                                                        <div class="tab-pane fade show active" id="google-contact"
                                                            role="tabpanel" aria-labelledby="google-contact-tab">
                                                            <div class="d-flex align-items-center"
                                                                style="position: relative;width:110px;">
                                                                <div class="checkbox-custom">
                                                                    <input type="checkbox" class="custom-checkbox-field" />
                                                                    <label>Select all</label>
                                                                </div>
                                                            </div>
                                                            <div class="people-list-section">
                                                                <ul class="people-list-view">
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user4-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kepler Willsn</h4>
                                                                            <h5>keplerwills@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user3-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jenifer Kenwood</h4>
                                                                            <h5>jeniferkenwood@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kevin Pieterson</h4>
                                                                            <h5>kevinpieterson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Serina Thomas</h4>
                                                                            <h5>serinathomas@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Clara Hamilton</h4>
                                                                            <h5>clarahamilton@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar04.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Hendry Joe</h4>
                                                                            <h5>hendryjoe@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar3.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Raymond Coven</h4>
                                                                            <h5>raymondcoven@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jannet Franklin</h4>
                                                                            <h5>jannetfranklin@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user8-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Linda Robinson</h4>
                                                                            <h5>lindarobinson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user7-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Georgia Math</h4>
                                                                            <h5>georgiamath@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user6-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Mike Jason</h4>
                                                                            <h5>mikejason@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user5-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Chris Moris</h4>
                                                                            <h5>chrismoris@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="facebook-contact" role="tabpanel"
                                                            aria-labelledby="facebook-contact-tab">
                                                            <div class="people-list-section">
                                                                <ul class="people-list-view">
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user8-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Linda Robinson</h4>
                                                                            <h5>lindarobinson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user7-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Georgia Math</h4>
                                                                            <h5>georgiamath@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user6-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Mike Jason</h4>
                                                                            <h5>mikejason@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user5-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Chris Moris</h4>
                                                                            <h5>chrismoris@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user4-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kepler Willsn</h4>
                                                                            <h5>keplerwills@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user3-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jenifer Kenwood</h4>
                                                                            <h5>jeniferkenwood@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kevin Pieterson</h4>
                                                                            <h5>kevinpieterson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Serina Thomas</h4>
                                                                            <h5>serinathomas@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Clara Hamilton</h4>
                                                                            <h5>clarahamilton@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar04.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Hendry Joe</h4>
                                                                            <h5>hendryjoe@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar3.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Raymond Coven</h4>
                                                                            <h5>raymondcoven@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jannet Franklin</h4>
                                                                            <h5>jannetfranklin@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="meetup-contact" role="tabpanel"
                                                            aria-labelledby="meetup-contact-tab">
                                                            <div class="people-list-section">
                                                                <ul class="people-list-view">
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user6-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Mike Jason</h4>
                                                                            <h5>mikejason@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user5-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Chris Moris</h4>
                                                                            <h5>chrismoris@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user4-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kepler Willsn</h4>
                                                                            <h5>keplerwills@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user3-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jenifer Kenwood</h4>
                                                                            <h5>jeniferkenwood@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user8-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Linda Robinson</h4>
                                                                            <h5>lindarobinson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user7-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Georgia Math</h4>
                                                                            <h5>georgiamath@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kevin Pieterson</h4>
                                                                            <h5>kevinpieterson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Serina Thomas</h4>
                                                                            <h5>serinathomas@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Clara Hamilton</h4>
                                                                            <h5>clarahamilton@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar04.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Hendry Joe</h4>
                                                                            <h5>hendryjoe@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar3.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Raymond Coven</h4>
                                                                            <h5>raymondcoven@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jannet Franklin</h4>
                                                                            <h5>jannetfranklin@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div class="tab-pane fade" id="event-contact" role="tabpanel"
                                                            aria-labelledby="event-contact-tab">
                                                            <div class="people-list-section">
                                                                <ul class="people-list-view">
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Clara Hamilton</h4>
                                                                            <h5>clarahamilton@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar04.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Hendry Joe</h4>
                                                                            <h5>hendryjoe@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar3.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Raymond Coven</h4>
                                                                            <h5>raymondcoven@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/avatar5.png')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jannet Franklin</h4>
                                                                            <h5>jannetfranklin@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user8-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Linda Robinson</h4>
                                                                            <h5>lindarobinson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user7-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Georgia Math</h4>
                                                                            <h5>georgiamath@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user6-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Mike Jason</h4>
                                                                            <h5>mikejason@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user5-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Chris Moris</h4>
                                                                            <h5>chrismoris@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user4-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kepler Willsn</h4>
                                                                            <h5>keplerwills@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user3-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Jenifer Kenwood</h4>
                                                                            <h5>jeniferkenwood@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Kevin Pieterson</h4>
                                                                            <h5>kevinpieterson@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                    <li class="share-card-item">
                                                                        <div class="img-invite-fig">
                                                                            <img src="<?php echo e(asset('dist/img/user1-128x128.jpg')); ?>"
                                                                                class="img-fluid" alt="user-img" />
                                                                        </div>
                                                                        <div class="user-detial-item">
                                                                            <h4>Serina Thomas</h4>
                                                                            <h5>serinathomas@mail.com</h5>
                                                                        </div>
                                                                        <div class="checkbox-custom">
                                                                            <input type="checkbox"
                                                                                class="custom-checkbox-field" />
                                                                            <label></label>
                                                                        </div>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-invite-header">
                                                    <h4>Share your class details and mange your sign ups all from one
                                                        place</h4>
                                                    <div class="d-flex align-items-center mt-3 mb-3"
                                                        style="position: relative;width:auto;">
                                                        <div class="checkbox-custom">
                                                            <input type="checkbox" class="custom-checkbox-field" />
                                                            <label>Sent invite to the all student in MYO</label>
                                                        </div>
                                                    </div>
                                                    <div class="d-flex select-group-dropdown">
                                                        <h4>Share invitation via email to your enrolled students</h4>
                                                        <button class="btn btn-secondary dropdown-toggle ml-auto"
                                                            type="button" id="dropdownMenuButton" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                            Select by group
                                                        </button>
                                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                            <a class="dropdown-item" href="#">Hauck Inc</a>
                                                            <a class="dropdown-item" href="#">Metz Inc</a>
                                                            <a class="dropdown-item" href="#">Zemlak group</a>
                                                            <a class="dropdown-item" href="#">Hoeger</a>
                                                        </div>
                                                    </div>
                                                    <div class="submit-btn-section">
                                                        <a href="<?php echo e(route('invitationshared')); ?>">
                                                            <div class="submit-btn-section text-center">
                                                                <button class="btn submit-btn">Share</button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
    </div>
    <footer class="main-footer">
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/instructor/offering/invite_share.blade.php ENDPATH**/ ?>