<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Edit Profile
                        </h4>
                    <div class="card-body dashboard-card-body">
                        <div class="add-form-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>Profile</h4>
                                </div>
                                <div class="card-body form-card-body">
                                    <form method="POST" action="<?php echo e(route('updateProfile')); ?>"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-12 col-md-4">
                                                <span class="left-profile-text"><?php echo e($userData->name); ?></span>
                                            </div>

                                            <div class="col-12 col-md-8">
                                                <div class="profile-img-edit">

                                                    <div class="avatar-upload">
                                                        <div class="avatar-edit">
                                                            <div class="text-center chat-image mb-5">
                                                                <div class="avatar avatar-xxl chat-profile mb-3 brround">
                                                                    <a class=""
                                                                        href="<?php echo e(route('InstructorsProfileImage', auth()->user()->id)); ?>">
                                                                        <img alt="avatar"
                                                                            src="<?php echo e(route('InstructorsProfileImage', auth()->user()->id)); ?>"
                                                                            class="brround" id="imgPreview">
                                                                    </a>
                                                                    <div class="edit-item">
                                                                        <div style="height:0px;overflow:hidden">
                                                                            <input type="file" name="profieImage"
                                                                                id="imageUpload"
                                                                                accept=".png, .jpg, .jpeg" />
                                                                        </div>
                                                                        <button type="button"
                                                                            onclick="chooseFile();"class="btn edit--profile-btn "><img
                                                                                src="dist/img/edit.png" alt="edit-icon"
                                                                                class="img-fluid" /></button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Full Name</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="row form-group mb4">
                                                        <div class="col-12 col-md-6">
                                                            <div class="myo-form-section">
                                                                <input
                                                                    class="form-control <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    type="text" name="firstName"
                                                                   <?php if(old('firstName')): ?>  value="<?php echo e(old('firstName')); ?>" <?php else: ?>  value="<?php echo e($userData->first_name); ?>" <?php endif; ?>
                                                                    placeholder="First Name">
                                                                <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-12 col-md-6">
                                                            <div class="myo-form-section">
                                                                <input
                                                                    class="form-control <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                    type="text" name="lastName"
                                                                    <?php if(old('lastName')): ?> value="<?php echo e(old('lastName')); ?>" <?php else: ?> value="<?php echo e($userData->last_name); ?>" <?php endif; ?>
                                                                    placeholder="Last Name">
                                                                <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                    <span class="invalid-feedback" role="alert">
                                                                        <strong><?php echo e($message); ?></strong>
                                                                    </span>
                                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Business Name </span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['businessName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="businessName"
                                                            <?php if(old('businessName')): ?> value="<?php echo e(old('businessName')); ?>" <?php else: ?> value="<?php echo e($userData->business_name); ?>" <?php endif; ?>
                                                            placeholder="Enter Business Name">
                                                        <?php $__errorArgs = ['businessName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Teacher Credentials</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                     <div class="myo-form-section multi-select-input">
                                                       <!-- <input
                                                            class="form-control <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="credentials"
                                                            <?php if(old('credentials')): ?> value="<?php echo e(old('credentials')); ?>" <?php else: ?> value="<?php echo e($userData->credentials); ?>" <?php endif; ?>
                                                            placeholder="Enter Credential">
                                                        <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> -->
                                                        <select  class="select2 form-control  multi-select-section <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  multiple="multiple" type="text" name="credentials[]" placeholder="Select Credential">
                                                        <option value="">Select Credentials</option>
                                                        <?php $__currentLoopData = $credentials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($credential->id); ?>"  <?php if(in_array($credential->id, $teacherCredentialValue)): ?> selected <?php endif; ?>>
                                                                <?php echo e($credential->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <option>Other</option>
                                                    </select>
                                                    <?php $__errorArgs = ['credentials'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Additional Education</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input type="text" class="form-control <?php $__errorArgs = ['education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  name="education" style="width: 100%;"  <?php if(old('education')): ?> value="<?php echo e(old('education')); ?>" <?php else: ?> value="<?php echo e($userData->education); ?>" <?php endif; ?> placeholder="Enter Education">
                                                        <?php $__errorArgs = ['education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Years of experience</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="experience"
                                                            <?php if(old('experience')): ?> value="<?php echo e(old('experience')); ?>" <?php else: ?> value="<?php echo e($userData->experience); ?>" <?php endif; ?>
                                                            placeholder="Enter Years of experience">
                                                        <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Teacher Specialties</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <?php $__currentLoopData = $yogatype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yoga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <input name="specialties" type="radio" value="<?php echo e($yoga->id); ?>"><?php echo e($yoga->type); ?>

                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__errorArgs = ['specialties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Website</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input class="form-control <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="website"
                                                            <?php if(old('website')): ?> value="<?php echo e(old('website')); ?>" <?php else: ?> value="<?php echo e($userData->website); ?>" <?php endif; ?>
                                                            placeholder="Enter Website URL">
                                                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Instagram</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="instagram"
                                                           <?php if(old('instagram')): ?>  value="<?php echo e(old('instagram')); ?>" <?php else: ?>  value="<?php echo e($userData->instagram); ?>" <?php endif; ?>
                                                            placeholder="Enter Instagram URL">
                                                        <?php $__errorArgs = ['instagram'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Facebook</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="facebook"
                                                            <?php if(old('facebook')): ?> value="<?php echo e(old('facebook')); ?>" <?php else: ?> value="<?php echo e($userData->facebook); ?>" <?php endif; ?>
                                                            placeholder="Enter Facebook URL">
                                                        <?php $__errorArgs = ['facebook'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Twitter</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input class="form-control <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="twitter"
                                                            <?php if(old('twitter')): ?> value="<?php echo e(old('twitter')); ?>" <?php else: ?> value="<?php echo e($userData->twitter); ?>" <?php endif; ?>
                                                            placeholder="Enter Twitter URL">
                                                        <?php $__errorArgs = ['twitter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Tik Tok</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input class="form-control  <?php $__errorArgs = ['tiktok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="tiktok"
                                                            <?php if(old('tiktok')): ?> value="<?php echo e(old('tiktok')); ?>" <?php else: ?> value="<?php echo e($userData->tiktok); ?>" <?php endif; ?>
                                                            placeholder="Enter Tiktok URL">
                                                        <?php $__errorArgs = ['tiktok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Youtube</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input class="form-control <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="youtube"
                                                            <?php if(old('youtube')): ?> value="<?php echo e(old('youtube')); ?>" <?php else: ?> value="<?php echo e($userData->youtube); ?>" <?php endif; ?>
                                                            placeholder="Enter Youtube URL">
                                                        <?php $__errorArgs = ['youtube'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Yoga Alliance Profile</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['allianceProfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="text" name="allianceProfile"
                                                            <?php if(old('allianceProfile')): ?> value="<?php echo e(old('allianceProfile')); ?>"
                                                            <?php else: ?> value="<?php echo e($userData->alliance_profile); ?>" <?php endif; ?>
                                                            placeholder="Enter Yoga Alliance Profile URL">
                                                        <?php $__errorArgs = ['allianceProfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Description</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="description"
                                                            <?php if(old('description')): ?> value="<?php echo e(old('description')); ?>" <?php else: ?> value="<?php echo e($userData->description); ?>" <?php endif; ?>
                                                            placeholder="Introduce yourself and share your journey with the community"><?php echo e($userData->description); ?></textarea>
                                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">Address Line 1</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section">
                                                            <input type="text"
                                                                class="form-control  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="address1"
                                                                <?php if(old('address1')): ?> value="<?php echo e(old('address1')); ?>" <?php else: ?> value="<?php echo e($imagedata->address1); ?>" <?php endif; ?>
                                                                placeholder="Address" />
                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">Address Line 2</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section">
                                                            <input type="text"
                                                                class="form-control  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="address2"
                                                                <?php if(old('address2')): ?> value="<?php echo e(old('address2')); ?>" <?php else: ?> value="<?php echo e($imagedata->address2); ?>" <?php endif; ?>
                                                                placeholder="Address" />
                                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">Country</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section student-profile-country">
                                                            <select
                                                                class="form-control select2 <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="country" id="country-dropdown">
                                                                <option value="" selected="selected">Select Country
                                                                </option>
                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($country->id); ?>"
                                                                        <?php if($country->id == $imagedata->country_id): ?> selected <?php endif; ?>>
                                                                        <?php echo e($country->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">State</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section student-profile-country">
                                                            <select
                                                                class="form-control select2  <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                style="width: 100%;" name="state" id="state-dropdown">
                                                                
                                                                <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($state->id); ?>"
                                                                        <?php if($state->id == $imagedata->state_id): ?> selected <?php endif; ?>>
                                                                        <?php echo e($state->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">City</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section student-profile-country">
                                                            <select
                                                                class="form-control select2  <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="city" id="city-dropdown">
                                                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($city->id); ?>"
                                                                        <?php if($city->id == $imagedata->city_id): ?> selected <?php endif; ?>>
                                                                        <?php echo e($city->name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>  
                                                <div class="row form-group mb4">
                                                    <div class="col-12 col-md-4">
                                                        <span class="left-profile-text">Zipcode</span>
                                                    </div>
                                                    <div class="col-12 col-md-8">
                                                        <div class="myo-form-section">
                                                            <input type="text"
                                                                class="form-control  <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                name="zipcode"
                                                                <?php if(old('zipcode')): ?> value="<?php echo e(old('zipcode')); ?>" <?php else: ?> value="<?php echo e($imagedata->zipcode); ?>" <?php endif; ?>
                                                                placeholder="Enter Zipcode" />
                                                            <?php $__errorArgs = ['zipcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="invalid-feedback" role="alert">
                                                                    <strong><?php echo e($message); ?></strong>
                                                                </span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Current Password</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['currentPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="password" name="currentPassword"
                                                            placeholder="Enter Current Password">
                                                        <?php $__errorArgs = ['currentPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <?php if(\Session::has('error')): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo \Session::get('error'); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">New Password</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input
                                                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            type="password" name="password"
                                                            placeholder="Enter New Password">
                                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($message); ?></strong>
                                                            </span>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row form-group mb4">
                                                <div class="col-12 col-md-4">
                                                    <span class="left-profile-text">Confirm Password</span>
                                                </div>
                                                <div class="col-12 col-md-8">
                                                    <div class="myo-form-section">
                                                        <input class="form-control" type="password"
                                                            name="password_confirmation"
                                                            placeholder="Enter Confirm Password">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="submit-btn-section">
                                                <div class="submit-btn-section text-center">
                                                    <button type="submit" class="btn submit-btn">Save</button>
                                                </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <footer class="main-footer">
        </div> -->
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();2
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").change(function() {
            readURL(this);
        });

        //choose file script
        function chooseFile() {
            $("#imageUpload").click();
        }

        $(document).ready(() => {
            $('#imageUpload').change(function() {
                const file = this.files[0];
                if (file) {
                    let reader = new FileReader();
                    reader.onload = function(event) {
                        console.log(event.target.result);
                        $('#imgPreview').attr('src', event.target.result);
                    }
                    reader.readAsDataURL(file);
                }
            });
        });
        $(document).ready(function() {
            $('#country-dropdown').on('change', function() {
                var country_id = this.value;
                $("#state-dropdown").html('');
                $.ajax({
                    url: "<?php echo e(route('getState')); ?>",
                    type: "GET",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        country_id: country_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#state-dropdown').html('<option value="">Select State</option>');
                        $.each(result.states, function(key, value) {
                            $("#state-dropdown").append('<option value="' + value.id +
                                '">' + value.name + '</option>');
                        });
                        $('#city-dropdown').html(
                            '<option value="">Select State First</option>');

                    }
                });
            });
            $('#state-dropdown').on('change', function() {
                var state_id = this.value;
                $("#city-dropdown").html('');
                $.ajax({
                    url: "<?php echo e(url('get-cities-by-state')); ?>",
                    type: "POST",
                    data: {
                        state_id: state_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#city-dropdown').html('<option value="">Select City</option>');
                        $.each(result.cities, function(key, value) {
                            $("#city-dropdown").append('<option value="' + value.id +
                                '">' + value.name + '</option>');
                        });
                    }

                });
            });
           
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\myoo-latest\resources\views/instructor/profile/edit.blade.php ENDPATH**/ ?>