<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Myo</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('dist/img/logo-myo.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="../../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
    <link rel="stylesheet" href="../../dist/css/custom.css">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body class="hold-transition login-page login-bg-img-item">
    <div class="login-box login-custom-box-section landingLogo">
        <div class="landing-page-logo-item">
            <a href="/login" class="landing-logo-section">
                <img src="<?php echo e(asset('dist/img/logo-myo.png')); ?>" class="img-fluid" alt="logo" />
            </a>
        </div>
        <p class="copyright-text-item">© 2022 MYO</p>
    </div>
    <div class="login-box login-custom-box-section landingLoginform" style="display: none">
        <div class="card-header card-top-header-item">
            <div class="login-logo">
                <a href="/"><img src="<?php echo e(asset('dist/img/logo-myo.png')); ?>" /></a>
                <p class="login-box-msg">Sign in to your MYO account</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body login-card-body">
                <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                            value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Email" autofocus>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class=""><img src="<?php echo e(asset('dist/img/user.svg')); ?>" class="img-fluid"
                                        alt="user-icon" /></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" placeholder="Password"
                            class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                            autocomplete="current-password">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span><img src="<?php echo e(asset('dist/img/unlock.svg')); ?>" class="img-fluid"
                                        alt="user-icon" /></span>
                            </div>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <p class="text-right forgot-psw-text">
                                <a href="<?php echo e(route('password.request')); ?>">I forgot my password</a>
                            </p>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block myo-sign-btn">Sign In</button>
                        </div>
                    </div>
                </form>
                <div class="mb-0 signup-btn-bottom-text">
                    Don’t have an account? <a href="/register" class="text-center">Sign up</a>
                </div>
                <div class="social-auth-links text-center">
                    <a href="<?php echo e(url('auth/google')); ?>" class="btn social-icon-login-btn">
                        <img src="<?php echo e(asset('dist/img/google-1.png')); ?>" class="img-fluid" />
                    </a>
                    <a href="#" class="btn social-icon-login-btn">
                        <img src="<?php echo e(asset('dist/img/twitter-1.png')); ?>" class="img-fluid" />
                    </a>
                    <a href="<?php echo e(url('auth/facebook')); ?>" class="btn social-icon-login-btn">
                        <img src="<?php echo e(asset('dist/img/facebook.png')); ?>" class="img-fluid" />
                    </a>
                    <a href="#" class="btn social-icon-login-btn">
                        <img src="<?php echo e(asset('dist/img/apple-logo.png')); ?>" class="img-fluid" />
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/js/adminlte.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $('.landingLoginform').show();
                $('.landingLogo').hide();
            }, 2000);
        });
    </script>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\projects\myoo-latest\resources\views/logins/login.blade.php ENDPATH**/ ?>