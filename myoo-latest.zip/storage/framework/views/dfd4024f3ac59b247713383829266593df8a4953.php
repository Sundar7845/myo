<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none"stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Profile & Settings
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">
                        <div class="table-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>My profile</h4>
                                </div>
                                <div class="card-body p-4">
                                    <div class="user-profile-card-section">
                                        <div class="user-profile-card-header">
                                            <div class="profile-img-section">
                                                <div class="text-center chat-image mb-5">
                                                    <div class="avatar avatar-xxl chat-profile mb-3 brround">
                                                        <a class=""
                                                            href="<?php echo e(route('studentProfileImage', auth()->user()->id)); ?>"
                                                            target="blank">
                                                            <img alt="avatar"
                                                                src="<?php echo e(route('studentProfileImage', auth()->user()->id)); ?>"
                                                                class="brround">
                                                        </a>
                                                    </div>
                                                </div>
                                                <div>
                                                    <h4><?php echo e($userData->name); ?></h4>
                                                    <p><?php echo e($userData->email); ?></p>
                                                    <h5><?php echo e($userData->description); ?></h5>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="user-profile-card-body">
                                            <div class="row">
                                                <div class="col-12 col-md-6">
                                                    <div class="text-ijh-list ">
                                                        <h6 class="text-small">Mobile</h6>
                                                        <h5 class="text-high-line"><?php echo e($userData->mobile); ?></h5>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <div class="text-ijh-list ">
                                                        <h6 class="text-small">Permit Number</h6>
                                                        <h5 class="text-high-line"><?php echo e($userData->permit_number); ?></h5>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <div class="text-ijh-list ">
                                                        <h6 class="text-small">Address</h6>
                                                        <h5 class="text-high-line"><?php echo e($userData->address1); ?></h5>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <div class="text-ijh-list ">
                                                        <h6 class="text-small">Zipcode</h6>
                                                        <h5 class="text-high-line"><?php echo e($userData->zipcode); ?></h5>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="edit-button-section">
                                            <a href="/student-edit-profile" class="btn edit_profile-btn">Edit
                                                Profile</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    </div>
    <footer class="main-footer">
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\myoo-karthi\resources\views/student/profile/view.blade.php ENDPATH**/ ?>