<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header explore-filter">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M12.5 22.2715C18.0228 22.2715 22.5 17.7943 22.5 12.2715C22.5 6.74864 18.0228 2.27148 12.5 2.27148C6.97715 2.27148 2.5 6.74864 2.5 12.2715C2.5 17.7943 6.97715 22.2715 12.5 22.2715Z" />
                                    <path d="M16.74 8.03149L14.62 14.3915L8.26001 16.5115L10.38 10.1515L16.74 8.03149Z" />
                                </svg>
                            </span>
                            Explore
                        </h4>
                        <div class="search-filter-section">
                            <div class="search-fielditem">
                                <input type="text" class="form-control" placeholder="Search" />
                                <span class="search-icon">
                                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="magnifying-glass"
                                        role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                        class=" docs-search-decorative z-foreground svg-inline--fa fa-magnifying-glass fa-fw fa-lg">
                                        <path
                                            d="M500.3 443.7l-119.7-119.7c27.22-40.41 40.65-90.9 33.46-144.7C401.8 87.79 326.8 13.32 235.2 1.723C99.01-15.51-15.51 99.01 1.724 235.2c11.6 91.64 86.08 166.7 177.6 178.9c53.8 7.189 104.3-6.236 144.7-33.46l119.7 119.7c15.62 15.62 40.95 15.62 56.57 0C515.9 484.7 515.9 459.3 500.3 443.7zM79.1 208c0-70.58 57.42-128 128-128s128 57.42 128 128c0 70.58-57.42 128-128 128S79.1 278.6 79.1 208z"
                                            class=""></path>
                                    </svg>
                                </span>
                            </div>
                            <div class="filter-section">
                                <button class="btn filter-btm item" data-toggle="modal" data-target="#filterModal">
                                    <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="list-ul"
                                        role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"
                                        class="svg-inline--fa fa-list-ul fa-lg">
                                        <path
                                            d="M16 96C16 69.49 37.49 48 64 48C90.51 48 112 69.49 112 96C112 122.5 90.51 144 64 144C37.49 144 16 122.5 16 96zM480 64C497.7 64 512 78.33 512 96C512 113.7 497.7 128 480 128H192C174.3 128 160 113.7 160 96C160 78.33 174.3 64 192 64H480zM480 224C497.7 224 512 238.3 512 256C512 273.7 497.7 288 480 288H192C174.3 288 160 273.7 160 256C160 238.3 174.3 224 192 224H480zM480 384C497.7 384 512 398.3 512 416C512 433.7 497.7 448 480 448H192C174.3 448 160 433.7 160 416C160 398.3 174.3 384 192 384H480zM16 416C16 389.5 37.49 368 64 368C90.51 368 112 389.5 112 416C112 442.5 90.51 464 64 464C37.49 464 16 442.5 16 416zM112 256C112 282.5 90.51 304 64 304C37.49 304 16 282.5 16 256C16 229.5 37.49 208 64 208C90.51 208 112 229.5 112 256z"
                                            class=""></path>
                                    </svg> Filter
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body dashboard-card-body">
                        <div class="video-container">
                            <div class="video-title-text">
                                <h3>Famous classes of the day</h3>
                            </div>
                            <div class="row edit-screen-card">
                            <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="<?php if($key==0): ?> col-md-8 <?php else: ?> col-md-4 <?php endif; ?> edit-screen-column-card">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="<?php if($key==0): ?> slider-video-section <?php else: ?> video-section-small <?php endif; ?>">
                                            <div class="video-view-item">
                                                <img src="<?php echo e(route('instructor.offers',$value->id)); ?>" alt="" class="img-fluid">
                                            </div>
                                            <div class="overlay-content-text">
                                                <div class="d-flex align-items-center">
                                                    <div class="user-img"><a class=""
                                                        href="<?php echo e(route('instructor.profileimage', $value->users->id)); ?>" target="_blank">
                                                        <img alt="avatar"
                                                            src="<?php echo e(route('instructor.profileimage', $value->users->id)); ?>"
                                                            class="img-fluid edit-section-image"
                                                            alt="user-pic" /></a>
                                                    </div>
                                                    <h6><?php echo e($value->users->name); ?></h6>
                                                </div>
                                                <h4><?php echo e($value->title); ?></h4>
                                                <p><?php echo e($value->describe_offering); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>    
                                </div>              
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>         
                        </div>
                    </div>
                </div>
            </div>
    </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <!-- Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="filter-nav-tab-section">
                        <div class="d-flex">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="instructor-tab" data-toggle="tab" href="#instructor"
                                        role="tab" aria-controls="instructor" aria-selected="true">Instructor</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="level-tab" data-toggle="tab" href="#level" role="tab"
                                        aria-controls="level" aria-selected="false">Level</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="duration-tab" data-toggle="tab" href="#duration"
                                        role="tab" aria-controls="duration" aria-selected="false">Duration</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="fee-tab" data-toggle="tab" href="#fee" role="tab"
                                        aria-controls="fee" aria-selected="false">Fee</a>
                                </li>
                            </ul>
                            <button type="button" class="close ml-auto" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="instructor" role="tabpanel"
                                aria-labelledby="instructor-tab">
                                <div class="instructor-list">
                                    <?php $__currentLoopData = $userList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="p-0 m-0">
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                            <a class=""
                                                        href="<?php echo e(route('instructor.profileimage', $value->id)); ?>" target="_blank">
                                                        <img alt="avatar"
                                                            src="<?php echo e(route('instructor.profileimage', $value->id)); ?>"
                                                            class="img-fluid edit-section-image"
                                                            alt="user-pic" /></a>
                                            </div>
                                            <div class="instructor-detail">
                                                <h4><?php echo e($value->name); ?></h4>
                                                <p><?php echo e($value->email); ?></p>
                                            </div>
                                        </li>
                                    </ul>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="level" role="tabpanel" aria-labelledby="level-tab">...
                            </div>
                            <div class="tab-pane fade" id="duration" role="tabpanel" aria-labelledby="fee-tab">...
                            </div>
                            <div class="tab-pane fade" id="fee" role="tabpanel" aria-labelledby="fee-tab">...
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Clear</button>
                    <button type="button" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <footer class="main-footer">
    </footer>
    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
    <script>
        $(document).ready(function() {

            $("#carousel").owlCarousel({
                autoplay: true,
                rewind: true,
                /* use rewind if you don't want loop */
                margin: 25,
                dots: false,
                /*
              animateOut: 'fadeOut',
              animateIn: 'fadeIn',
              */
                responsiveClass: true,
                autoHeight: true,
                autoplayTimeout: 7000,
                smartSpeed: 800,
                nav: false,
                responsive: {
                    0: {
                        items: 1
                    },

                    600: {
                        items: 2
                    },

                    1024: {
                        items: 3
                    },

                    1366: {
                        items: 2.8
                    },

                    1440: {
                        items: 3.6
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\myoo-karthi\resources\views/dashboard.blade.php ENDPATH**/ ?>