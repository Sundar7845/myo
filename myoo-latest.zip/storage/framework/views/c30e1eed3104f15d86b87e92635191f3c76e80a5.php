<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Myo</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('dist/img/logo-myo.png')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free/css/all.min.css')); ?>">
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/custom.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@200;300;400;500;600;700&display=swap"
        rel="stylesheet">
</head>

<body class="hold-transition register-page login-bg-img-item">
    <div class="register-box login-box login-custom-box-section">
        <div class="card-top-header-item">
            <div class="login-logo">
                <a href="/login"><img src="<?php echo e(asset('dist/img/logo-myo.png')); ?>" /></a>
                <p class="login-box-msg">Choose Usertype to your MYO account</p>
            </div>
        </div>
        <div class="card">
            <div class="card-body register-card-body">
                <form method="POST" action="<?php echo e(route('userType')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="user-select-section">
                            <label class="d-block">Select User</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" value="1" type="radio" name="user_type">
                            <label class="form-check-label">Instructor</label>
                        </div>
                        <div class="form-check ml-3">
                            <input class="form-check-input" value="2" type="radio" name="user_type" checked>
                            <label class="form-check-label">Student</label>
                        </div>
                    </div>
                    <div class="col-6">
                        <button type="submit" class="btn btn-primary btn-block myo-sign-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <p class="copyright-text-item">© 2022 MYO</p>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/popup.blade.php ENDPATH**/ ?>