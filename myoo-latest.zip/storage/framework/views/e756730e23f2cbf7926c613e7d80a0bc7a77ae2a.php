<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="view-profile-section">
                    <div class="card profile-card-section">
                        <div class="profile-card-header card-header <?php if(\Session::has('success')): ?> profileSuccess <?php endif; ?>">
                            <?php if(\Session::has('success')): ?>
                                <div class="alert alert-success ">
                                    <div class="alert-icon text-center">
                                        <i class="fa fa-check"></i>
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="alert-message text-center">
                                        <strong>Success!</strong> <?php echo \Session::get('success'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="d-flex align-items-center">
                                <h4>
                                    <span>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22"
                                            viewBox="0 0 22 22" fill="none" stroke="#474B4F" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round">
                                            <path
                                                d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                        </svg>
                                    </span>
                                    View Profile
                                </h4>
                                <div class="ml-auto">
                                    <a href="/edit-profile" class="profile-edit-btn btn">Edit Profile</a>
                                </div>
                            </div>
                        </div>
                        <div class="profile-card-body card-body">
                            <div class="profile-item-inner">
                                <div class="profile-img-section">
                                    <div class="text-center chat-image mb-5">
                                        <div class="avatar avatar-xxl chat-profile mb-3 brround">
                                            <a class=""
                                                href="<?php echo e(route('InstructorsProfileImage', auth()->user()->id)); ?>">
                                                <img alt="avatar"
                                                    src="<?php echo e(route('InstructorsProfileImage', auth()->user()->id)); ?>"
                                                    class="brround">
                                            </a>
                                        </div>
                                        <div class="main-chat-msg-name">
                                            <a href="profile.html">
                                                <h5 class="mb-1 text-dark fw-semibold"><?php echo e($userData->name); ?></h5>
                                            </a>
                                            <p class="text-muted mt-0 mb-0 pt-0 fs-13">instructor</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="profile-content-right">
                                    <div class="profile-detail-fields">
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Full Name</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <span><?php echo e($userData->name); ?></span>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Business Name </label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <span><?php echo e($userData->business_name); ?></span>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Teacher Credentials & Education</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <span><?php echo e($userData->credentials); ?></span>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Years of experience</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <span><?php echo e($userData->experience); ?></span>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Teacher Specialties </label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <span><?php echo e($userData->specialties); ?></span>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Website</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->website); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->website); ?></a>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Instagram</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->instagram); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->instagram); ?></a>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Facebook</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->facebook); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->facebook); ?></a>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Twitter</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->twitter); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->twitter); ?></a>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Tik Tok</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->tiktok); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->tiktok); ?></a>
                                            </div>
                                        </div>
                                        <div class="row mb-3">
                                            <div class="col-12 col-md-4">
                                                <label>Yoga Alliance Profile</label>
                                            </div>
                                            <div class="col-12 col-md-8">
                                                <a href="<?php echo e($userData->alliance_profile); ?>" class="social-link-item"
                                                    target="blank"><?php echo e($userData->alliance_profile); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <footer class="main-footer">
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            setTimeout(function() {
                $('.profile-card-header').removeClass('profileSuccess');
            }, 3000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\myoo-karthi\resources\views/instructor/profile/view.blade.php ENDPATH**/ ?>