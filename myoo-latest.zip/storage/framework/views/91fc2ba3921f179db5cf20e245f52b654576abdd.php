<?php $__env->startSection('extra_header'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/css/bootstrap-datepicker.min.css" />

    <script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/timepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery_weekdays.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="list-unstyled">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none" stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Manage Classes
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">

                        <div class="add-form-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>Adding a Class</h4>
                                </div>
                                <div class="card-body form-card-body">
                                    <form action="<?php echo e(route('store')); ?>" method="POST" enctype="multipart/form-data"
                                        id="upload_form" name="upload_form">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <input type="hidden" id="start_date" name="start_date">
                                            
                                            <input type="hidden" id="end_date" name="end_date">
                                            
                                            <input type="hidden" id="frequencylist" name="frequencylist">
                                            <input type="hidden" id="timezonelist" name="timezonelist">

                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Title</label>
                                                    <input type="text" placeholder="Title" name="title" id="title"
                                                        class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Offering</label>
                                                    <select class="form-control  <?php $__errorArgs = ['offer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        style="width: 100%;" name="offer">
                                                        <option value="">Select Offer</option>
                                                        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($offer->id); ?>">
                                                                <?php echo e($offer->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </select>
                                                    <?php $__errorArgs = ['offer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Class</label>
                                                    <select class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        style="width: 100%;" name="class" id="class_field">
                                                        <option value="">Select Class</option>
                                                        <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($classes->id); ?>">
                                                                <?php echo e($classes->type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6 yoga_class">
                                                <div class="form-group myo-form-section multi-select-input">
                                                    <label>Type of Yoga </label>
                                                    <select class="select2 form-control multi-select-section"
                                                        multiple="multiple" data-placeholder="Select yoga types"
                                                        style="width: 100%;" name="yoga_type[]" id="yoga_types">
                                                        <option value="">Select yogatype </option>
                                                        <?php $__currentLoopData = $yogatypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yogatype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($yogatype->id); ?>">
                                                                <?php echo e($yogatype->type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <div class="cancel-icon-multi-select">
                                                        <button type="button"><img src="./dist/img/cross.png"
                                                                alt="" width="18"></button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Schedule</label>
                                                    <input class="form-control" type="text" placeholder="Enter"
                                                        data-toggle="modal" data-target="#scheduleModal" id="schedule"
                                                        name="schedule" autocomplete="off" >
                                                    <?php $__errorArgs = ['schedule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Venue</label>
                                                    <select class="form-control <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        style="width: 100%;" name="venue" id="venue">
                                                        <option value="">Select Venue</option>
                                                        <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($venue->id); ?>">
                                                                <?php echo e($venue->title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['venue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6 link">
                                                <div class="form-group myo-form-section">
                                                    <label>URL for Online Class</label>
                                                    <input class="form-control" type="text" placeholder="Enter"
                                                        name="link" id="link">
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6 location_link">
                                                <div class="form-group myo-form-section">
                                                    <label>Private Location</label>
                                                    <select class="form-control" style="width: 100%;"
                                                        name="private_location" id="private_location">
                                                        <option value="">Select Location</option>
                                                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($location->id); ?>">
                                                                <?php echo e($location->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <option id="search">Add new venue</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Max Attendees</label>
                                                    <input
                                                        class="form-control <?php $__errorArgs = ['max_attendees'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        type="text" placeholder="Enter" name="max_attendees">
                                                    <?php $__errorArgs = ['max_attendees'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Payments Type </label>
                                                    <select
                                                        class="form-control <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        style="width: 100%;" name="payment_type">
                                                        <option value="">Select Payments Type
                                                        </option>
                                                        <?php $__currentLoopData = $paymenttypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymenttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($paymenttype->id); ?>">
                                                                <?php echo e($paymenttype->type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div
                                                    class="form-group myo-form-section multi-select-input my-offering-section">
                                                    <label>Props Needed</label>
                                                    <select
                                                        class="select2 form-control multi-select-section <?php $__errorArgs = ['props_needed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        multiple="multiple" type="text"
                                                        data-placeholder="Select Props Types " name="props_needed[]"
                                                        id="props_needed">
                                                        <option value="">Select Props</option>
                                                        <?php $__currentLoopData = $property; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $props): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($props->id); ?>">
                                                                <?php echo e($props->property_type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['props_needed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback " role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Accessibility</label>
                                                    <input class="form-control" type="text" placeholder="Enter"
                                                        name="accessibility">
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Describe your offering</label>
                                                    <textarea class="form-control" type="text" placeholder="Describe your offering" name="describe_offering"></textarea>
                                                </div>
                                            </div>
                                            <div class="col-6">
                                                <div class="form-group myo-form-section">
                                                    <label>Personal notes</label>
                                                    <textarea class="form-control" type="text" placeholder="Personal notes" name="personal_notes"></textarea>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <label>Add media</label>
                                        <div class="progress-bar-section-loader">
                                            <input type="file" id="myFile" name="filename">
                                            <progress id="progressBar" value="0" max="100"
                                                style="width:300px;"></progress>
                                            <img id="imgPreview" style="width:300px; height:250px" hidden src="#"
                                                alt="pic" />
                                            <h3 id="status"></h3>
                                            <p id="loaded_n_total"></p>
                                        </div>

                                        <div class="submit-btn-section">
                                            <a href="<?php echo e(route('summary')); ?>">
                                                <div class="submit-btn-section text-center">
                                                    <button class="btn submit-btn">Submit</button>
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--modal-popup-schedule-->
            <div class="modal fade" id="scheduleModal" tabindex="-1" role="dialog"
                aria-labelledby="scheduleModalLabel" aria-hidden="true">
                <div class="modal-dialog Schedule-modal-popup" role="document">
                    <div class="modal-content Schedule-modal-content">
                        <div class="modal-header header-section text-right d-block border-0">
                            <button type="button" class="close schedule-close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body ">
                            <div class="schedule-modal-header">
                                <button type="button" class="Schedule-modal-time-button"><input
                                        class="form-control Schedule-form-input calender-section" type="text"
                                        placeholder="MM/DD/YYYY" name="startdate" id="startdate"></button>
                                <button type="button" class="Schedule-modal-time-button"><input
                                        class="form-control Schedule-form-input time-section" type="text"
                                        placeholder="HH/MM" name="starttime" id="starttime"></button>
                                <h6 class="schedule-button-center-text">to</h6>
                                <button type="button" class="Schedule-modal-time-button"><input
                                        class="form-control Schedule-form-input calender-section" type="text"
                                        placeholder="MM/DD/YYYY" name="enddate" id="enddate"></button>
                                <button type="button" class="Schedule-modal-time-button"><input
                                        class="form-control Schedule-form-input time-section" type="text"
                                        placeholder="HH/MM" name="endtime" id="endtime"></button>

                            </div>
                            <div class="schedule-modal-body-content">
                                <select class="select2 form-control schedule-select-box col-md-4" name="timezone"
                                    id="timezone_list">
                                    <option value="">Timezone</option>
                                    <?php $__currentLoopData = $timezones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timezone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option data-value="<?php echo e($timezone->id); ?>" value="<?php echo e($timezone->id); ?>">
                                            <?php
                                                $mytitle = trim($timezone->offset . $timezone->utc_by_country);
                                            ?>
                                            <?php echo e($mytitle); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <div class="form-check form-check-inline schedule-all-day">
                                    <label class="custom-schedule-check">
                                        <input type="checkbox">
                                        <span class="checkmark"></span>
                                        All Day
                                    </label>
                                </div>
                                <select class="form-control schedule-select-box col-md-4" name="frequency"
                                    id="frequency_list">
                                    <option value="">Does not repeat</option>
                                    <?php $__currentLoopData = $frequencytypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frequencytype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option data-value="<?php echo e($frequencytype->type); ?>"
                                            value="<?php echo e($frequencytype->id); ?>"><?php echo e(trim($frequencytype->type)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer schedule-modal-footer">

                            <button type="button" class="btn btn-primary schedule-save-button" name="save"
                                id="saveschedule" data-dismiss="modal">Save</button>
                            <!--Does-not-repeat-custom-modal-->
                            <div class="modal fade" id="customRepeatModal" tabindex="-1" role="dialog"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog custom-repeat-modal-card" role="document">
                                    <div class="modal-content custom-repeat-card">
                                        <div class="modal-header custom-repeat-modal">
                                            <h6 class="modal-title repeat-title" id="exampleModalLabel">Custom
                                                recurrence</h6>
                                            <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body repeat-body-content">
                                            <div class="repeat-date-section">
                                                <p>Repeat every</p>
                                                <button type="button"
                                                    class="Schedule-modal-time-button custom-repeat"><input
                                                        class="form-control Schedule-form-input" type="number"
                                                        placeholder="0"></button>
                                                <div class="dropdown show">
                                                    <select class="form-select" name="cliente" id="days">
                                                        <option value="">Select types</option>
                                                        <?php $__currentLoopData = $customfrequencytypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customfrequencytype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($customfrequencytype->id); ?>">
                                                                <?php echo e($customfrequencytype->type); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="repeat-week-button-section" id="weekdays">
                                            <p>Repeat on</p>
                                            <input type="checkbox" class="weekly-days-button">S</button>
                                            <input type="checkbox" class="weekly-days-button">M</button>
                                            <input type="checkbox" class="weekly-days-button">T</button>
                                            <input type="checkbox" class="weekly-days-button">W</button>
                                            <input type="checkbox" class="weekly-days-button">T</button>
                                            <input type="checkbox" class="weekly-days-button">F</button>
                                            <input type="checkbox" class="weekly-days-button">S</button>
                                        </div>
                                        <div class="repeat-end-section">
                                            <p>Ends</p>
                                            <div class="radio-buttons">
                                                <div class="form-group radio-form">
                                                    <input type="radio" id="never" name="day" />
                                                    <label for="never">Never</label>
                                                </div>
                                                <div class="form-group radio-form">
                                                    <input type="radio" id="on" name="day" />
                                                    <label for="on">On</label>
                                                    <button type="button"
                                                        class="Schedule-modal-time-button radio-box-section"><input
                                                            class="form-control Schedule-form-input" type="text"
                                                            id="customdate"></button>
                                                </div>
                                                <div class="form-group radio-form">
                                                    <input type="radio" id="always" name="day" />
                                                    <label for="always">After</label>
                                                    <div>
                                                        <button type="button"
                                                            class="Schedule-modal-time-button custom-repeat"><input
                                                                class="form-control Schedule-form-input" type="number"
                                                                placeholder="0"></button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer repeat-footer">
                                        <button type="button" class="btn btn-secondary"
                                            data-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-primary">Done</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </section>
    </div>
    <footer class="main-footer">
    </footer>
    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
    <script src="<?php echo e(asset('js/jqueryvalidation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/offering-script.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#country-dropdown').on('change', function() {
                var country_id = this.value;
                $("#state-dropdown").html('');
                $.ajax({
                    url: "<?php echo e(url('get-states-by-country')); ?>",
                    type: "GET",
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    data: {
                        country_id: country_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#state-dropdown').html('<option value="">Select State</option>');
                        $.each(result.states, function(key, value) {
                            $("#state-dropdown").append('<option value=""' + value.id +
                                '">' + value.name + '</option>');
                        });
                        $('#city-dropdown').html(
                            '<option value="">Select State First</option>');
                    }
                });
            });
            $('#state-dropdown').on('change', function() {
                var state_id = this.value;
                $("#city-dropdown").html('');
                $.ajax({
                    url: "<?php echo e(url('get-cities-by-state')); ?>",
                    type: "POST",
                    data: {
                        state_id: state_id,
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    dataType: 'json',
                    success: function(result) {
                        $('#city-dropdown').html('<option value="">Select City</option>');
                        $.each(result.cities, function(key, value) {
                            $("#city-dropdown").append('<option value="' + value.id +
                                '">' + value.name + '</option>');
                        });
                    }

                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-latest\resources\views/instructor/offering/add.blade.php ENDPATH**/ ?>