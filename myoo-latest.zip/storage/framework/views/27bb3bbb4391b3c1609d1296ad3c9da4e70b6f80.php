<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-body dashboard-card-body">
                        <div class="table-view-section invitation-success-box">
                            <div class="card invitation-outer-card">
                                <div class="card-body">
                                    <div class="Successfully-inivitaion-section">
                                        <h2 class="invitation-share-header">Invitation Shared Successfully</h2>
                                        <img src="./dist/img/check-icon.png" alt=""
                                            class="img-fluid invitatio-check-image" width="100" height="auto" />
                                        <p class="success-description-para">You will be notified through email
                                            once<span class="d-block"> the student accepted the invitation</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    </div>
    <footer class="main-footer">
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\myoo-latest\resources\views/instructor/offering/invitation_shared.blade.php ENDPATH**/ ?>