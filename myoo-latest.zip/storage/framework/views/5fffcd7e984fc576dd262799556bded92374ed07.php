<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none"stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            My Instructor
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">
                        <div class="table-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>Instructor List</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="offering-table-item">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Instructor Name</th>
                                                <th>Email</th>
                                                <th>Overall Rating</th>
                                                <th>Mobile No</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody><?php
                                            $serialNo = 1;
                                        ?>
                                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($serialNo); ?></td>
                                                    <td><?php echo e($student->name); ?></td>
                                                    <td><?php echo e($student->email); ?></td>
                                                    <td>4.2</td>
                                                    <td><?php echo e($student->mobile); ?></td>
                                                    <td> <a href="<?php echo e(route('studentinstructor.view', ['id' => $student->created_by])); ?>"
                                                            class="btn btn-link btn-sm"><i class="far fa-eye"></i> View</a>
                                                    </td>
                                                </tr>
                                                <?php
                                                    $serialNo++;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    <!-- /.content -->
    <!-- Modal -->
    <div class="modal fade" id="filterModal" tabindex="-1" role="dialog" aria-labelledby="filterModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="filter-nav-tab-section">
                        <div class="d-flex">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="instructor-tab" data-toggle="tab" href="#instructor"
                                        role="tab" aria-controls="instructor" aria-selected="true">Instructor</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="level-tab" data-toggle="tab" href="#level" role="tab"
                                        aria-controls="level" aria-selected="false">Level</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="duration-tab" data-toggle="tab" href="#duration" role="tab"
                                        aria-controls="duration" aria-selected="false">Duration</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="fee-tab" data-toggle="tab" href="#fee" role="tab"
                                        aria-controls="fee" aria-selected="false">Fee</a>
                                </li>
                            </ul>
                            <button type="button" class="close ml-auto" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="instructor" role="tabpanel"
                                aria-labelledby="instructor-tab">
                                <div class="instructor-list">
                                    <ul class="p-0 m-0">
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/avatar2.png" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Airi Satou</h4>
                                                <p>airisatou@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/avatar3.png" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Bradley Greer</h4>
                                                <p>bradleygreer@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/avatar04.png" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Brielle Williamson</h4>
                                                <p>briellewilliamson@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/avatar5.png" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Cara Stevens</h4>
                                                <p>carastevens@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/user1-128x128.jpg" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Cedric Kelly</h4>
                                                <p>cedrickellyu@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/user2-160x160.jpg" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Bruno Nash</h4>
                                                <p>brunonash@mail.com</p>
                                            </div>
                                        </li>
                                        <li class="inner-cell-list-user">
                                            <div class="user-img-item">
                                                <img src="dist/img/user3-128x128.jpg" class="img-fluid" alt="user-img" />
                                            </div>
                                            <div class="instructor-detail">
                                                <h4>Angelica Ramos</h4>
                                                <p>angelicaramos@mail.com</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="level" role="tabpanel" aria-labelledby="level-tab">...
                            </div>
                            <div class="tab-pane fade" id="duration" role="tabpanel" aria-labelledby="fee-tab">
                                ...</div>
                            <div class="tab-pane fade" id="fee" role="tabpanel" aria-labelledby="fee-tab">
                                ...</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Clear</button>
                    <button type="button" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <footer class="main-footer">
    </footer>

    <aside class="control-sidebar control-sidebar-dark">
    </aside>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/student/instructor/index.blade.php ENDPATH**/ ?>