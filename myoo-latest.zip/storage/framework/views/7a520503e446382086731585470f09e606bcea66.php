<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">

        <section class="content">
            <div class="container-fluid">
                <div class="dashboard--section card">
                    <div class="card-header dashboard-card-header">
                        <h4>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"
                                    fill="none"stroke="#474B4F" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <path
                                        d="M11 1L14.09 7.26L21 8.27L16 13.14L17.18 20.02L11 16.77L4.82 20.02L6 13.14L1 8.27L7.91 7.26L11 1Z" />
                                </svg>
                            </span>
                            Manage Classes
                        </h4>
                    </div>
                    <div class="card-body dashboard-card-body">
                        <div class="table-view-section">
                            <div class="card table-card-view">
                                <div class="card-header table-card-header">
                                    <h4>Classes List</h4>
                                </div>
                            </div>
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show"
                                    role="alert">
                                    <?php echo e(Session::get('message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="offering-table-item">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Class Name</th>
                                                
                                                
                                                <th>Location Type</th>
                                                <th>Date & Time</th>
                                                <th>Payment Status</th>
                                                <th>Payable Balance</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                $serialNo = 1;
                                            ?>
                                            <?php $__currentLoopData = $manageoffers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manageoffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($serialNo); ?></td>
                                                    <td><?php echo e($manageoffer->offerDetails->title); ?></td>
                                                    
                                                    <td><?php echo e($manageoffer->offerDetails->venue->title); ?></td>
                                                    <?php
                                                        $start_date = date('d-m-Y h:i A', strtotime($manageoffer->offerDetails->start_date));
                                                        $end_date = date('d-m-Y h:i A', strtotime($manageoffer->offerDetails->end_date));

                                                        $dates = implode(' - ', [$start_date, $end_date]);
                                                    ?>
                                                    <td><?php echo e($dates); ?>

                                                    </td>
                                                    <td> <span class="paid-text">Paid</span></td>
                                                    <td>$0</td>
                                                    <td>
                                                        <form action="<?php echo e(route('studentclass.destroy',$manageoffer->id)); ?>" method="GET" style="display: inline-block">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <input name="_method" type="hidden" value="DELETE">
                                                            <button
                                                                class="btn btn-danger btn-sm btn-danger btn-flat" id="cancel"
                                                                type="submit" data-toggle="tooltip" title='Cancel'>Cancel</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                                <?php
                                                    $serialNo++;
                                                ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    </section>
    <!-- <script src="<?php echo e(asset('js/cancel-confirmation.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/student/manage_class/index.blade.php ENDPATH**/ ?>