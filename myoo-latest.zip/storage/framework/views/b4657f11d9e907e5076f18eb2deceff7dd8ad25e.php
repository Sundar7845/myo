<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css" integrity="sha512-1sCRPdkRXhBV2PBLUdRb4tMg1w2YPf37qatUFeS7zlBy7jJI8Lf4VHwWfZZfpXtYSLy85pkm9GaYVYMfw5BC1A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<ul class="social">
    <li><a href="<?= $share->facebook(); ?>" target="_blank"><i class="fa-brands fa-facebook"></i></a></li>
    <li><a href="<?= $share->twitter(/* $username */); ?>" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
    <li><a href="<?= $share->linkedin(/* $summary, $source */); ?>" target="_blank"><i class="fa-brands fa-linkedin"></i></a></li>
    <li><a href="<?= $share->pinterest(/* $image */); ?>" target="_blank"><i class="fa-brands fa-pinterest"></i></a></li>
    <li><a href="<?= $share->whatsapp(); ?>" target="_blank"><i class="fa-brands fa-whatsapp"></i></a></li>
    <li><a href="<?= $share->telegram(); ?>" target="_blank"><i class="fa-brands fa-telegram"></i></a></li>
    <li><a href="<?= $share->reddit(); ?>" target="_blank"><i class="fa-brands fa-reddit"></i></a></li>
    <li><a href="<?= $share->email(/* $recipientEmail */); ?>" target="_blank"><i class="fa-regular fa-envelope"></i></a></li>
    <li><a id= "copy"><i class="fa-solid fa-link"></i></a></li>
</ul>

<style>

    #copy{
        color:#008cff;
    }

    .social{
        margin-left: 600px;
    }

    .social li {
        display: inline-block;
        }          
    .social li a {
                padding: 10px;
                font-size: 30px;
                color: #008cff;
                background-color: #fff;
            }
</style>
<script>
    $('#copy').click(function () { 
        var copy = "http://127.0.0.1:8000/dashboard";
        alert('"copied to clipboard"')
        copyToClipboard(copy); 
    });

function copyToClipboard(text) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val(text).select();
    document.execCommand("copy");
    $temp.remove();
}
</script>

<?php /**PATH D:\xampp\htdocs\projects\myoo-karthick\resources\views/instructor/offering/socialmedia.blade.php ENDPATH**/ ?>